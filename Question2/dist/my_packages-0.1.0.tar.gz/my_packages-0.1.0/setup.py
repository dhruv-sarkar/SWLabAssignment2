from setuptools import setup

setup(
   name='my_packages',
   version='0.1.0',
   author='Dhruv Sarkar',
   author_email='dhruv.sarkar223@gmail.com',
   packages=['my_package', 'lavis'],
   description='Package made for my Software Engineering Laboratory Assignment',
   )
